package id.btn.automation.pages;

import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import org.openqa.selenium.By;
import org.springframework.stereotype.Component;


import static com.codeborne.selenide.Selenide.$;
@Component
public class HitungHargaProperti {
//    public static Object findElementByCss;
    public SelenideElement inputPenghasilanTotal = $("input[placeholder='Penghasilan Total']");
    public SelenideElement inputPengeluaran = $("input[placeholder='Pengeluaran']");
    public SelenideElement inputJangkaWaktu = $("html > body > div > div > section > div > div > div > div:nth-of-type(2) > div > div > div:nth-of-type(2) > form > div:nth-of-type(1) > div:nth-of-type(3)");
    public SelenideElement inputJangkaWaktu_01 = $("option[value='5']");
    public SelenideElement dropdownTenor = $("select[id='waktu']");
    public SelenideElement select5Tahun = $("option[value='5']");
    public SelenideElement buttonHitungUlang = $("#hitung_harga_button");
    public SelenideElement textHargaPropertiMaksimal = $("#harga_hasil");

    public SelenideElement findElementByCSS(SelenideElement cssSelector) {
        return $(By.cssSelector(cssSelector.toString()));
    }

    public SelenideElement findDropdownByValue(String val) {
        val = String.format("option[value='%s']", val);
        return $(By.cssSelector(val));
    }
}

