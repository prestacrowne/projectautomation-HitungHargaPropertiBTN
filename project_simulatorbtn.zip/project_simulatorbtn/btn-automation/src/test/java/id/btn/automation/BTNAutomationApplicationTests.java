package id.btn.automation;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Driver;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;
import id.btn.automation.pages.HitungHargaProperti;
import id.btn.automation.repositories.entities.DataEntity;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileReader;
import java.io.Reader;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.codeborne.selenide.Selenide.open;
import static com.codeborne.selenide.Selenide.sleep;

@Slf4j
@SpringBootTest
public class BTNAutomationApplicationTests {

    @Autowired
    private HitungHargaProperti hitungHargaProperti;

    private static List<DataEntity> dataTest = new ArrayList<>();

    public void readFile() throws Exception {
        String[] HEADERS = {"Penghasilan total", "Pengeluaran", "Jangka waktu"};
        Reader reader = new FileReader("data test btn.csv");
        CSVFormat csvFormat = CSVFormat.DEFAULT.builder()
                .setHeader(HEADERS)
                .setSkipHeaderRecord(true)
                .build();

        Iterator<CSVRecord> records = csvFormat.parse(reader).iterator();
        for (Iterator<CSVRecord> it = records; it.hasNext(); ) {
            CSVRecord record = it.next();
            int penghasilan = Integer.parseInt(record.get(0));
            int pengeluaran = Integer.parseInt(record.get(1));
            String tenor = record.get(2);
            dataTest.add(new DataEntity(penghasilan, pengeluaran, tenor));
        }
    }

    @Test
    public void simulasiPriceRumahBTN() throws Exception {
        readFile();
        for (DataEntity data : dataTest) {
            String productUrl = "https://www.btnproperti.co.id/tools/hitung-harga-properti";
            open(productUrl);
            hitungHargaProperti.inputPenghasilanTotal.setValue(Integer.toString(data.Penghasilan));
            hitungHargaProperti.inputPengeluaran.setValue(Integer.toString(data.Pengeluaran));
            hitungHargaProperti.dropdownTenor.click();
            hitungHargaProperti.findDropdownByValue(data.Tenor).click();
            hitungHargaProperti.buttonHitungUlang.click();

            sleep(3000);
            var valElement = hitungHargaProperti.textHargaPropertiMaksimal.$("h3");
            var hargaElement = valElement.innerText();
            String hargaStr = hargaElement.replaceAll("[^0-9]", "");
            int harga = Integer.parseInt(hargaStr);
            int tenor = Integer.parseInt(data.Tenor.replaceAll("[^0-9]", ""));
            int expectedHarga = (data.Penghasilan - data.Pengeluaran) * tenor / 3;
            if (harga != expectedHarga) {
            }
        }
    }
}

