package id.btn.automation.repositories.entities;

public class DataEntity {
    public static int Penghasilan;
    public static int Pengeluaran;
    public static String Tenor;

    public DataEntity(int penghasilan, int pengeluaran, String tenor) {
        Penghasilan = penghasilan;
        Pengeluaran = pengeluaran;
        Tenor = tenor;
    }
}